#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Quantix Flask App - Routes automatiques
Connecte toutes les pages HTML et gère les uploads / exports
"""

import os
import time
from flask import Flask, render_template, request, redirect, url_for, send_from_directory, flash
from werkzeug.utils import secure_filename
from werkzeug.exceptions import RequestEntityTooLarge
from modules import cleaner as cleaner_module

# === CONFIGURATION ===
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'uploads')
EXPORT_FOLDER = os.path.join(BASE_DIR, 'exports')
TEMPLATE_FOLDER = os.path.join(BASE_DIR, 'templates')
STATIC_FOLDER = os.path.join(BASE_DIR, 'static')

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(EXPORT_FOLDER, exist_ok=True)

ALLOWED_EXTENSIONS = {'csv', 'txt', 'json', 'xlsx', 'xls', 'pdf', 'png', 'jpg', 'jpeg', 'wav', 'mp3','mp4'}

app = Flask(__name__,
            template_folder=TEMPLATE_FOLDER,
            static_folder=STATIC_FOLDER)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['EXPORT_FOLDER'] = EXPORT_FOLDER
# Security / config
# Prefer reading secret from environment in production. Keep a dev fallback.
app.secret_key = os.environ.get('QUANTIX_SECRET_KEY', 'dev-quantix-secret')  # à personnaliser en prod
# Limit max upload size (16 MiB)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

# === UTILITAIRES ===
def allowed_file(filename: str) -> bool:
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


# === ROUTES GÉNÉRIQUES ===
@app.route('/', endpoint='home')
def index():
    return render_template('index.html')



# === UPLOADS ===
@app.route('/upload', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('Aucun fichier détecté')
            return redirect(request.url)

        file = request.files['file']
        if file.filename == '':
            flash('Aucun fichier sélectionné')
            return redirect(request.url)

        if file and allowed_file(file.filename):
            # create a safer unique filename to avoid collisions
            safe_name = secure_filename(file.filename)
            filename = f"{int(time.time())}_{safe_name}"
            path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(path)
            flash(f"Fichier {filename} bien enregistré dans /uploads.")
            
            # si on vient du workflow nettoyage, lancer automatiquement le nettoyage
            referer = request.headers.get('Referer', '')
            if '/nettoyage' in referer or 'nettoyage' in request.form.get('source', ''):
                # rediriger vers nettoyer avec le nom du fichier
                return redirect(url_for('nettoyer') + f'?filename={filename}')
            else:
                # redirect to the dashboard listing uploads/exports
                return redirect(url_for('list_uploads'))
        else:
            flash('Extension non autorisée')
            return redirect(request.url)
    return render_template('essayer_pages/nettoyage.html')

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    """Affiche ou télécharge un fichier uploadé"""
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)


@app.route('/nettoyer', methods=['POST'])
def nettoyer():
    """Lance le nettoyage pour un fichier uploadé.

    Attend un champ de formulaire 'filename' correspondant au nom du fichier
    dans le dossier `uploads/` (tel qu'enregistré par `upload_file`).
    Enregistre le résultat nettoyé dans `exports/` et redirige vers le dashboard.
    """
    filename = request.form.get('filename') or request.args.get('filename')
    if not filename:
        flash('Aucun fichier spécifié pour le nettoyage')
        return redirect(url_for('dashboard'))

    # assure que le fichier existe dans le dossier uploads
    upload_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    if not os.path.exists(upload_path):
        flash(f"Fichier '{filename}' introuvable dans uploads.")
        return redirect(url_for('dashboard'))

    try:
        # appeler le cleaner (renvoie DataFrame et rapport)
        final_df, report = cleaner_module.process_files([upload_path])

        # enregistrer le DataFrame nettoyé
        base, ext = os.path.splitext(filename)
        out_name = f"cleaned_{int(time.time())}_{base}.csv"
        out_path = os.path.join(app.config['EXPORT_FOLDER'], out_name)
        # sauvegarde en CSV UTF-8
        final_df.to_csv(out_path, index=False, encoding='utf-8')

        flash(f"Nettoyage terminé — fichier exporté: {out_name}")
        # fournir un lien pratique vers l'export
        return redirect(url_for('list_exports'))
    except Exception as e:
        flash(f"Erreur lors du nettoyage : {e}")
        return redirect(url_for('dashboard'))


# === EXPORTS ===
@app.route('/export/<path:filename>')
def export_file(filename):
    """Télécharge un fichier généré dans /exports"""
    # Prevent path traversal by resolving real paths and ensuring the file is inside EXPORT_FOLDER
    export_path = os.path.join(EXPORT_FOLDER, filename)
    real_export = os.path.realpath(export_path)
    real_export_folder = os.path.realpath(EXPORT_FOLDER)
    try:
        if os.path.commonpath([real_export_folder, real_export]) != real_export_folder:
            return "Chemin d'export invalide.", 400
    except Exception:
        return "Chemin d'export invalide.", 400

    if os.path.exists(export_path):
        return send_from_directory(EXPORT_FOLDER, filename, as_attachment=True)
    return f"Fichier exporté '{filename}' introuvable.", 404


# === LISTE DES UPLOADS & EXPORTS ===
@app.route('/uploads')
def list_uploads():
    uploads = os.listdir(UPLOAD_FOLDER)
    exports = os.listdir(EXPORT_FOLDER)
    return render_template('dashboard.html', uploads=uploads, exports=exports)

@app.route('/exports')
def list_exports():
    uploads = os.listdir(UPLOAD_FOLDER)
    exports = os.listdir(EXPORT_FOLDER)
    return render_template('dashboard.html', uploads=uploads, exports=exports)

# === ROUTES EXPLICITES POUR CHAQUE TEMPLATE ===
# Définies une par une pour que les appels dans les templates puissent utiliser
# url_for('<nom>') sans BuildError (ex: url_for('fonctionnalites')).
@app.route('/apropos', endpoint='apropos')
def apropos():
    return render_template('apropos.html')

@app.route('/biblio', endpoint='biblio')
def biblio():
    return render_template('biblio.html')

@app.route('/confidentialite', endpoint='confidentialite')
def confidentialite():
    return render_template('confidentialite.html')

@app.route('/contact', endpoint='contact')
def contact():
    return render_template('contact.html')

@app.route('/dashboard', endpoint='dashboard')
def dashboard():
    uploads = os.listdir(UPLOAD_FOLDER)
    exports = os.listdir(EXPORT_FOLDER)
    return render_template('dashboard.html', uploads=uploads, exports=exports)

@app.route('/docs', endpoint='docs')
def docs():
    return render_template('docs.html')

@app.route('/essayer', endpoint='essayer')
def essayer():
    return render_template('essayer.html')

@app.route('/fonctionnalites', endpoint='fonctionnalites')
def fonctionnalites():
    return render_template('fonctionnalites.html')

@app.route('/ia', endpoint='ia')
def ia():
    return render_template('ia.html')

@app.route('/matrix', endpoint='matrix')
def matrix():
    return render_template('matrix.html')

@app.route('/mentions', endpoint='mentions')
def mentions():
    return render_template('mentions.html')

@app.route('/quantxplus', endpoint='quantxplus')
def quantxplus():
    return render_template('quantxplus.html')

@app.route('/essayer_pages/conversion', endpoint='conversion')
def conversion():
    return render_template('essayer_pages/conversion.html')

@app.route('/essayer_pages/nettoyage', endpoint='nettoyage')
def nettoyage():
    return render_template('essayer_pages/nettoyage.html')

@app.route('/essayer_pages/transcription', endpoint='transcription')
def transcription():
    return render_template('essayer_pages/transcription.html')

@app.route('/essayer_pages/visualisation', endpoint='visualisation')
def visualisation():
    return render_template('essayer_pages/visualisation.html')


# Generic template router that supports nested templates and prevents path traversal.
@app.route('/<path:page>')
def page_router(page):
    """
    Render any template under the `templates/` directory using its relative path.
    Examples:
      /dashboard -> templates/dashboard.html
      /essayer_pages/conversion -> templates/essayer_pages/conversion.html
    """
    try:
        # Normalize requested template path and ensure it ends with .html
        requested = page if page.endswith('.html') else f"{page}.html"
        template_path = os.path.join(TEMPLATE_FOLDER, requested)

        # Prevent path traversal: require real path to be inside TEMPLATE_FOLDER
        real_template = os.path.realpath(template_path)
        real_template_folder = os.path.realpath(TEMPLATE_FOLDER)
        if not real_template.startswith(real_template_folder):
            return "Chemin de template invalide.", 400

        if os.path.exists(real_template):
            # render_template expects a path relative to the templates folder
            rel_path = os.path.relpath(real_template, real_template_folder).replace(os.sep, '/')
            return render_template(rel_path)
        return f"Page '{page}' non trouvée.", 404
    except Exception as e:
        return f"Erreur : {e}", 500


# Error handler for too large uploads
@app.errorhandler(RequestEntityTooLarge)
def handle_file_too_large(e):
    flash('Fichier trop volumineux (limite 16 MiB).')
    return render_template('essayer_pages/nettoyage.html'), 413


# === MODE DEBUG ===
if __name__ == "__main__":
    app.run(debug=True, host='127.0.0.1', port=5000)

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Module de conversion de fichiers – Quantix Formator
Convertit entre CSV, Excel, JSON, TXT, PDF, DOCX, PowerPoint, Markdown, Image, Audio.
(Version allégée sans dépendance à moviepy)
"""

import os
import json
import pandas as pd
from pathlib import Path
from typing import Dict, Any, Optional
from datetime import datetime

# Modules optionnels
try:
    from docx import Document
    DOCX_AVAILABLE = True
except ImportError:
    DOCX_AVAILABLE = False

try:
    from pptx import Presentation
    PPTX_AVAILABLE = True
except ImportError:
    PPTX_AVAILABLE = False

try:
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    PDF_AVAILABLE = True
except ImportError:
    PDF_AVAILABLE = False

try:
    from PIL import Image
    IMAGE_AVAILABLE = True
except ImportError:
    IMAGE_AVAILABLE = False

try:
    from pydub import AudioSegment
    AUDIO_AVAILABLE = True
except ImportError:
    AUDIO_AVAILABLE = False


class FileFormator:
    """Convertisseur universel Quantix sans dépendances lourdes"""

    SUPPORTED_FORMATS = {
        "csv": ["csv"],
        "excel": ["xlsx", "xls"],
        "json": ["json"],
        "txt": ["txt"],
        "pdf": ["pdf"],
        "docx": ["docx"],
        "pptx": ["pptx"],
        "markdown": ["md"],
        "image": ["png", "jpg", "jpeg"],
        "audio": ["mp3", "wav", "ogg"],
        "video": ["mp4", "mov", "avi"]  # lecture partielle uniquement
    }

    def __init__(self, temp_dir: str = "temp_conversions"):
        self.temp_dir = Path(temp_dir)
        self.temp_dir.mkdir(exist_ok=True)
        self.log_file = self.temp_dir / "conversion_log.txt"

    # === MÉTHODES DE DÉTECTION ET LECTURE ===
    def detect_file_type(self, path: str) -> str:
        ext = Path(path).suffix.lower().lstrip(".")
        for t, exts in self.SUPPORTED_FORMATS.items():
            if ext in exts:
                return t
        return "unknown"

    def read_file(self, path: str) -> Dict[str, Any]:
        ftype = self.detect_file_type(path)
        try:
            if ftype == "csv":
                df = pd.read_csv(path)
                return {"type": "tabular", "raw": df}
            if ftype == "excel":
                df = pd.read_excel(path)
                return {"type": "tabular", "raw": df}
            if ftype == "json":
                with open(path, encoding="utf-8") as f:
                    data = json.load(f)
                return {"type": "json", "raw": data}
            if ftype in ["txt", "markdown"]:
                with open(path, encoding="utf-8") as f:
                    content = f.read()
                return {"type": "text", "raw": content}
            if ftype == "docx" and DOCX_AVAILABLE:
                doc = Document(path)
                text = "\n".join(p.text for p in doc.paragraphs)
                return {"type": "document", "raw": text}
            if ftype == "pdf":
                return {"type": "document", "raw": f"Fichier PDF ({Path(path).name})"}
            if ftype == "image" and IMAGE_AVAILABLE:
                img = Image.open(path)
                return {"type": "image", "size": img.size, "mode": img.mode, "path": path}
            if ftype == "audio" and AUDIO_AVAILABLE:
                audio = AudioSegment.from_file(path)
                return {"type": "audio", "duration": len(audio)/1000, "path": path}
            if ftype == "video":
                return self._read_video_meta(path)
        except Exception as e:
            self._log(f"Erreur lecture {path}: {e}")
            raise ValueError(f"Erreur lecture {path}: {e}")
        raise ValueError(f"Format non pris en charge: {path}")

    def _read_video_meta(self, path: str) -> Dict[str, Any]:
        """Lecture basique des métadonnées vidéo sans moviepy"""
        try:
            import subprocess
            result = subprocess.run(
                ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of",
                 "default=noprint_wrappers=1:nokey=1", path],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            duration = float(result.stdout.strip()) if result.stdout else 0
            return {"type": "video", "duration": duration, "path": path}
        except Exception:
            return {"type": "video", "duration": None, "path": path}

    # === CONVERSION PRINCIPALE ===
    def convert_file(self, input_path: str, output_format: str, output_path: Optional[str] = None) -> str:
        """Convertit un fichier vers un format de sortie"""
        data = self.read_file(input_path)
        output_format = output_format.lower().lstrip(".")
        output_path = output_path or str(self.temp_dir / f"{Path(input_path).stem}_converted.{output_format}")

        try:
            if output_format == "csv":
                return self._to_csv(data, output_path)
            if output_format in ["xlsx", "xls"]:
                return self._to_excel(data, output_path)
            if output_format == "json":
                return self._to_json(data, output_path)
            if output_format == "txt":
                return self._to_txt(data, output_path)
            if output_format == "md":
                return self._to_md(data, output_path)
            if output_format == "pdf":
                return self._to_pdf(data, output_path)
            if output_format == "docx":
                return self._to_docx(data, output_path)
            if output_format in ["png", "jpg", "jpeg"]:
                return self._to_image(data, output_path, output_format)
            if output_format in ["mp3", "wav"]:
                return self._to_audio(data, output_path, output_format)
            raise ValueError(f"Format de sortie non supporté: {output_format}")
        except Exception as e:
            self._log(f"Erreur conversion {input_path} -> {output_format}: {e}")
            raise

    # === MÉTHODES D’ÉCRITURE ===
    def _to_csv(self, data, path):
        if data["type"] == "tabular":
            data["raw"].to_csv(path, index=False)
        elif data["type"] == "json":
            pd.DataFrame([data["raw"]]).to_csv(path, index=False)
        else:
            with open(path, "w", encoding="utf-8") as f:
                f.write(str(data["raw"]))
        return path

    def _to_excel(self, data, path):
        if data["type"] == "tabular":
            data["raw"].to_excel(path, index=False)
        else:
            pd.DataFrame([{"content": str(data["raw"])}]).to_excel(path, index=False)
        return path

    def _to_json(self, data, path):
        json_data = data["raw"] if data["type"] != "tabular" else data["raw"].to_dict("records")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(json_data, f, indent=2, ensure_ascii=False)
        return path

    def _to_txt(self, data, path):
        with open(path, "w", encoding="utf-8") as f:
            if data["type"] == "tabular":
                f.write(data["raw"].to_string(index=False))
            else:
                f.write(str(data["raw"]))
        return path

    def _to_md(self, data, path):
        text = f"# {Path(path).stem}\n\n"
        if data["type"] == "tabular":
            text += data["raw"].to_markdown(index=False)
        else:
            text += str(data["raw"])
        with open(path, "w", encoding="utf-8") as f:
            f.write(text)
        return path

    def _to_pdf(self, data, path):
        if not PDF_AVAILABLE:
            raise ImportError("ReportLab requis pour export PDF.")
        doc = SimpleDocTemplate(path, pagesize=A4)
        styles = getSampleStyleSheet()
        story = [Paragraph(f"Export PDF – {datetime.now():%d/%m/%Y}", styles["Title"]), Spacer(1, 12)]
        if data["type"] == "tabular":
            table_data = [data["raw"].columns.tolist()] + data["raw"].values.tolist()
            table = Table(table_data)
            table.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0071ff")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                ("GRID", (0, 0), (-1, -1), 0.25, colors.grey)
            ]))
            story.append(table)
        else:
            story.append(Paragraph(str(data["raw"]), styles["Normal"]))
        doc.build(story)
        return path

    def _to_docx(self, data, path):
        if not DOCX_AVAILABLE:
            raise ImportError("python-docx requis.")
        doc = Document()
        doc.add_heading("Document converti Quantix", 0)
        if data["type"] == "tabular":
            df = data["raw"]
            table = doc.add_table(rows=1, cols=len(df.columns))
            hdr_cells = table.rows[0].cells
            for i, c in enumerate(df.columns):
                hdr_cells[i].text = str(c)
            for _, row in df.iterrows():
                row_cells = table.add_row().cells
                for i, v in enumerate(row):
                    row_cells[i].text = str(v)
        else:
            doc.add_paragraph(str(data["raw"]))
        doc.save(path)
        return path

    def _to_image(self, data, path, fmt):
        if not IMAGE_AVAILABLE:
            raise ImportError("Pillow requis.")
        img = Image.new("RGB", (800, 400), color="white")
        img.save(path, fmt.upper())
        return path

    def _to_audio(self, data, path, fmt):
        if not AUDIO_AVAILABLE:
            raise ImportError("pydub requis.")
        silence = AudioSegment.silent(duration=1000)
        silence.export(path, format=fmt)
        return path

    # === OUTILS ===
    def _log(self, msg: str):
        with open(self.log_file, "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {msg}\n")


# ===== UTILITAIRES =====
def convert_file_simple(input_path: str, output_format: str, output_path: Optional[str] = None) -> str:
    return FileFormator().convert_file(input_path, output_format, output_path)

"""Minimal clean module for MVP

Provides simple, stable utilities to:
- load tabular files (CSV, XLSX, JSON)
- detect CSV separator
- coerce obvious numeric columns
- clean nulls with user-chosen policies (drop / mean / mode)
- merge multiple datasets simply

Design goals: tiny, robust, easy to reason about. No fancy heuristics.
"""

from typing import List, Tuple, Optional
import pandas as pd
import csv
import os
import re


def detect_csv_separator(file_path: str, sample_size: int = 4096) -> str:
    """Try to detect CSV separator using csv.Sniffer, fallback to common separators.

    Returns a one-character separator (default ',').
    """
    common = [',', ';', '\t', '|']
    try:
        with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
            sample = f.read(sample_size)
            sniffer = csv.Sniffer()
            dialect = sniffer.sniff(sample)
            sep = dialect.delimiter
            if sep:
                return sep
    except Exception:
        pass

    # fallback: pick separator with most occurrences in first line
    try:
        with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
            first = f.readline()
            counts = {s: first.count(s) for s in common}
            best = max(counts, key=counts.get)
            return best
    except Exception:
        return ','


def load_table(file_path: str) -> pd.DataFrame:
    """Load a tabular file into a DataFrame. Supports .csv, .xls, .xlsx, .json.

    For CSVs the separator is auto-detected.
    """
    ext = os.path.splitext(file_path)[1].lower()
    if ext == '.csv':
        sep = detect_csv_separator(file_path)
        df = pd.read_csv(file_path, sep=sep, encoding='utf-8', engine='python')
        return df
    elif ext in ('.xls', '.xlsx'):
        return pd.read_excel(file_path)
    elif ext == '.json':
        try:
            # try JSON lines first
            return pd.read_json(file_path, lines=True)
        except ValueError:
            return pd.read_json(file_path)
    else:
        raise ValueError(f"Unsupported file extension: {ext}")


def _coerce_numeric_columns(df: pd.DataFrame, threshold: float = 0.6) -> Tuple[pd.DataFrame, List[str]]:
    """Try to coerce object columns to numeric when a large fraction converts cleanly.

    Returns (df, converted_columns)
    """
    converted = []
    for col in df.columns:
        if pd.api.types.is_numeric_dtype(df[col]):
            continue
        # attempt coercion
        coerced = pd.to_numeric(df[col].astype(str).str.strip().replace('', pd.NA), errors='coerce')
        non_na_ratio = coerced.notna().mean()
        if non_na_ratio >= threshold:
            df[col] = coerced
            converted.append(col)
    return df, converted


def clean_dataframe(
    df: pd.DataFrame,
    null_policy_numeric: str = 'mean',  # 'mean' or 'drop'
    null_policy_text: str = 'mode',     # 'mode' or 'drop'
    convert_numbers: bool = True,
    convert_threshold: float = 0.6
) -> Tuple[pd.DataFrame, dict]:
    """Clean DataFrame according to simple policies.

    Parameters:
    - null_policy_numeric: 'mean' to fill numeric NaN with column mean, or 'drop' to drop rows with numeric NaN
    - null_policy_text: 'mode' to fill text NaN with column mode, or 'drop' to drop rows with text NaN
    - convert_numbers: attempt to coerce object columns to numeric when >= convert_threshold convert

    Returns (cleaned_df, report)
    """
    report = {'rows_before': len(df), 'rows_after': None, 'converted_columns': [], 'filled': {}, 'dropped_rows': 0}

    # simple cleaning: strip string columns and normalize column names
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]

    obj_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()
    for c in obj_cols:
        try:
            df[c] = df[c].astype(str).str.strip().replace({'nan': pd.NA, 'None': pd.NA})
        except Exception:
            pass

    # optional coercion
    if convert_numbers:
        df, converted = _coerce_numeric_columns(df, threshold=convert_threshold)
        report['converted_columns'] = converted

    # identify numeric and text columns now
    numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
    text_cols = [c for c in df.columns if c not in numeric_cols]

    # build drop mask if any policy asks to drop rows with NaNs
    drop_mask = pd.Series(False, index=df.index)
    if null_policy_numeric == 'drop' and numeric_cols:
        drop_mask = drop_mask | df[numeric_cols].isnull().any(axis=1)
    if null_policy_text == 'drop' and text_cols:
        drop_mask = drop_mask | df[text_cols].isnull().any(axis=1)

    if drop_mask.any():
        df = df.loc[~drop_mask].reset_index(drop=True)
        report['dropped_rows'] = int(drop_mask.sum())

    # fill remaining NaNs
    filled = {}
    if null_policy_numeric == 'mean':
        for c in numeric_cols:
            if df[c].isnull().any():
                mean_val = df[c].mean()
                df[c] = df[c].fillna(mean_val)
                filled[c] = ('mean', float(mean_val) if pd.notna(mean_val) else None)

    if null_policy_text == 'mode':
        for c in text_cols:
            if df[c].isnull().any():
                try:
                    mode = df[c].mode(dropna=True)
                    fill_val = mode.iloc[0] if len(mode) > 0 else 'Unknown'
                except Exception:
                    fill_val = 'Unknown'
                df[c] = df[c].fillna(fill_val)
                filled[c] = ('mode', fill_val)

    report['filled'] = filled
    report['rows_after'] = len(df)
    return df, report


def merge_tables(dfs: List[pd.DataFrame], on: Optional[List[str]] = None, how: str = 'outer') -> pd.DataFrame:
    """Merge a list of DataFrames.

    If `on` is provided, performs successive merges on these keys.
    Otherwise, concatenates vertically (aligning columns).
    """
    if not dfs:
        return pd.DataFrame()
    if len(dfs) == 1:
        return dfs[0].copy()

    if on:
        merged = dfs[0].copy()
        for df in dfs[1:]:
            merged = pd.merge(merged, df, on=on, how=how)
        return merged
    else:
        # vertical concat, reset index
        return pd.concat(dfs, axis=0, ignore_index=True, sort=False)


def process_files(file_paths: List[str],
                  null_policy_numeric: str = 'mean',
                  null_policy_text: str = 'mode',
                  merge: bool = False,
                  merge_on: Optional[List[str]] = None) -> Tuple[pd.DataFrame, dict]:
    """Load one or more files, clean them and optionally merge.

    Returns (final_df, report)
    """
    dfs = []
    reports = {}
    for p in file_paths:
        df = load_table(p)
        cleaned, rep = clean_dataframe(df, null_policy_numeric=null_policy_numeric, null_policy_text=null_policy_text)
        dfs.append(cleaned)
        reports[os.path.basename(p)] = rep

    if merge:
        final = merge_tables(dfs, on=merge_on, how='outer')
    else:
        final = dfs[0] if dfs else pd.DataFrame()

    overall = {
        'files_processed': len(file_paths),
        'per_file': reports,
        'final_shape': final.shape
    }
    return final, overall


if __name__ == '__main__':
    # quick smoke test when run directly
    sample = os.path.join(os.path.dirname(__file__), '..', 'data', 'cleaned_cleaned_test.csv')
    if os.path.exists(sample):
        df = load_table(sample)
        cleaned, report = clean_dataframe(df)
        print('Sample cleaned shape:', cleaned.shape)
        print('Report:', report)
    else:
        print('No sample file found for quick test.')

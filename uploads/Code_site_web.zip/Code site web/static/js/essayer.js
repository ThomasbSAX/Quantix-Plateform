// ===== INTERFACE ESSAYER - NOUVELLE INTÉGRATION AVEC CLASSES SPÉCIALISÉES =====

document.addEventListener('DOMContentLoaded', function() {
    // ===== ÉLÉMENTS INTERFACE MINIMALISTE =====
    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('fileInput');
    const fileSection = document.getElementById('fileSection');
    const fileActionsSection = document.getElementById('fileActionsSection');
    
    // Map des icônes d'extensions
    const EXTENSION_ICON_MAP = {
        "csv": "csv.png",
        "xlsx": "excel.png",
        "xls": "excel.png",
        "json": "markdown.png",
        "txt": "txt.png",
        "pdf": "pdf.png",
        "docx": "docx.png",
        "png": "png.png",
        "jpeg": "jpeg.png",
        "jpg": "jpeg.png",
        "mp3": "mp3.png",
        "mp4": "mp4.png",
        "wav": "mp3.png",
        "avi": "mp4.png",
        "mov": "mp4.png",
        "m4a": "mp3.png",
        "pptx": "powerpoint.png"
    };
    
    // Informations fichier
    const fileName = document.getElementById('fileName');
    const fileSize = document.getElementById('fileSize');
    const fileIcon = document.getElementById('fileIcon');
    
    // Statistiques
    const rowCount = document.getElementById('rowCount');
    const colCount = document.getElementById('colCount');
    const missingCount = document.getElementById('missingCount');
    const duplicateCount = document.getElementById('duplicateCount');
    
    // Boutons actions (nouveaux IDs)
    const convertBtn = document.getElementById('convertBtn');
    const cleanBtn = document.getElementById('cleanBtn');
    const visualizeBtn = document.getElementById('visualizeBtn');
    const dashboardBtn = document.getElementById('dashboardBtn');
    const reportBtn = document.getElementById('reportBtn');
    const transcribeBtn = document.getElementById('transcribeBtn');
    
    // Modal graphiques
    const chartsModal = document.getElementById('chartsModal');
    const closeChartsModal = document.getElementById('closeChartsModal');
    
    let currentFileData = null;
    let analysisComplete = false;

    // ===== ÉVÉNEMENTS PRINCIPAUX =====
    dropZone?.addEventListener('dragover', handleDragOver);
    dropZone?.addEventListener('drop', handleDrop);
    dropZone?.addEventListener('dragleave', handleDragLeave);
    dropZone?.addEventListener('click', () => fileInput?.click());
    
    fileInput?.addEventListener('change', handleFileSelect);
    
    // Actions fichier (nouveaux boutons) - Attacher les événements immédiatement
    function attachEventListeners() {
        convertBtn?.addEventListener('click', handleConvert);
        cleanBtn?.addEventListener('click', handleClean);
        visualizeBtn?.addEventListener('click', showChartsModal);
        dashboardBtn?.addEventListener('click', goToDashboard);
        reportBtn?.addEventListener('click', generateReport);
        transcribeBtn?.addEventListener('click', handleTranscribe);
        
        console.log('Event listeners attachés aux boutons d\'action');
    }
    
    // Attacher les événements immédiatement
    attachEventListeners();
    
    // Fonction de test pour vérifier les boutons
    function testButtons() {
        console.log('🔍 Test des boutons :');
        console.log('convertBtn:', convertBtn ? 'trouvé' : 'non trouvé');
        console.log('cleanBtn:', cleanBtn ? 'trouvé' : 'non trouvé');
        console.log('visualizeBtn:', visualizeBtn ? 'trouvé' : 'non trouvé');
        console.log('dashboardBtn:', dashboardBtn ? 'trouvé' : 'non trouvé');
        console.log('reportBtn:', reportBtn ? 'trouvé' : 'non trouvé');
        console.log('transcribeBtn:', transcribeBtn ? 'trouvé' : 'non trouvé');
    }
    
    // Lancer le test après un court délai pour s'assurer que le DOM est chargé
    setTimeout(testButtons, 1000);
    
    // Modal graphiques
    closeChartsModal?.addEventListener('click', hideChartsModal);
    chartsModal?.addEventListener('click', (e) => {
        if (e.target === chartsModal) hideChartsModal();
    });
    
    // Options graphiques
    document.querySelectorAll('.chart-option').forEach(option => {
        option.addEventListener('click', () => selectChart(option.dataset.type));
    });

    function handleDragOver(e) {
        e.preventDefault();
        dropZone.classList.add('drag-over');
    }

    function handleDragLeave(e) {
        e.preventDefault();
        dropZone.classList.remove('drag-over');
    }

    function handleDrop(e) {
        e.preventDefault();
        dropZone.classList.remove('drag-over');
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            processFile(files[0]);
        }
    }

    function handleFileSelect(e) {
        const files = e.target.files;
        if (files.length > 0) {
            const file = files[0];
            
            // Affichage immédiat des infos de base du fichier
            displayBasicFileInfo(file);
            
            // Traitement complet du fichier
            processFile(file);
        }
    }

    function displayBasicFileInfo(file) {
        const fileName = file.name;
        const fileSize = file.size < 1024 * 1024 
            ? (file.size / 1024).toFixed(1) + " KB"
            : (file.size / (1024 * 1024)).toFixed(1) + " MB";
        const ext = fileName.split(".").pop().toLowerCase();

        // Mise à jour des éléments
        if (document.getElementById('fileName')) {
            document.getElementById('fileName').textContent = fileName;
        }
        if (document.getElementById('fileSize')) {
            document.getElementById('fileSize').textContent = fileSize;
        }

        // Icône basée sur l'extension
        const iconFile = EXTENSION_ICON_MAP[ext] || "txt.png";
        const fileIcon = document.getElementById('fileIcon');
        if (fileIcon) {
            fileIcon.innerHTML = `<img src="/static/image/${iconFile}" class="file-type-image" style="width: 32px; height: 32px;">`;
        }

        // Afficher la section fichier
        if (fileSection) {
            fileSection.style.display = "block";
        }
    }

    async function processFile(file) {
        // Validation du fichier
        const allowedTypes = ['.csv', '.xlsx', '.xls', '.json', '.txt', '.mp3', '.mp4', '.wav', '.avi', '.mov', '.m4a'];
        const fileExtension = '.' + file.name.split('.').pop().toLowerCase();
        
        if (!allowedTypes.includes(fileExtension)) {
            showError('Type de fichier non supporté. Utilisez: CSV, Excel, JSON, TXT, MP3, MP4, WAV');
            return;
        }

        // Afficher le loader
        showLoader('Analyse du fichier en cours...');
        
        try {
            // Upload et analyse via nos nouvelles classes
            const formData = new FormData();
            formData.append('file', file);
            
            const response = await fetch('/upload-file', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (!result.success) {
                throw new Error(result.error);
            }
            
            // Stocker les données analysées
            currentFileData = result;
            analysisComplete = true;
            
            // Afficher les VRAIES informations du fichier
            displayRealFileInfo(result);
            
            // Activer les boutons en retirant l'attribut disabled et ajoutant les event listeners
            if (convertBtn) {
                convertBtn.disabled = false;
                convertBtn.classList.remove('disabled');
                convertBtn.classList.add('enabled');
            }
            if (cleanBtn) {
                cleanBtn.disabled = false;
                cleanBtn.classList.remove('disabled');
                cleanBtn.classList.add('enabled');
            }
            if (visualizeBtn) {
                visualizeBtn.disabled = false;
                visualizeBtn.classList.remove('disabled');
                visualizeBtn.classList.add('enabled');
            }
            if (dashboardBtn) {
                dashboardBtn.disabled = false;
                dashboardBtn.classList.remove('disabled');
                dashboardBtn.classList.add('enabled');
            }
            if (reportBtn) {
                reportBtn.disabled = false;
                reportBtn.classList.remove('disabled');
                reportBtn.classList.add('enabled');
            }
            if (transcribeBtn) {
                transcribeBtn.disabled = false;
                transcribeBtn.classList.remove('disabled');
                transcribeBtn.classList.add('enabled');
            }
            
            hideLoader();
            showSuccess('Fichier analysé avec succès !');
            
        } catch (error) {
            hideLoader();
            showError(`Erreur lors de l'analyse: ${error.message}`);
        }
    }

    function displayRealFileInfo(data) {
        console.log('Données reçues:', data); // Debug
        const { file_info, data_stats, column_info, preview } = data;
        
        // === AFFICHAGE DU FICHIER ===
        if (fileName) fileName.textContent = file_info.name;
        if (fileSize) fileSize.textContent = file_info.size_formatted || `${file_info.size_mb} MB`;
        
        // Icône selon l'extension RÉELLE - utilise le mapping d'images
        const ext = file_info.extension.replace('.', '').toLowerCase();
        const iconFile = EXTENSION_ICON_MAP[ext] || "txt.png";
        if (fileIcon) {
            fileIcon.innerHTML = `<img src="/static/image/${iconFile}" class="file-type-image" style="width: 32px; height: 32px;">`;
        }
        
        // === VRAIES STATISTIQUES ===
        if (rowCount) {
            rowCount.textContent = data_stats.rows.toLocaleString();
            console.log('Lignes mises à jour:', data_stats.rows);
        }
        if (colCount) {
            colCount.textContent = data_stats.columns.toLocaleString();
            console.log('Colonnes mises à jour:', data_stats.columns);
        }
        if (missingCount) {
            missingCount.textContent = data_stats.missing_values.toLocaleString();
            console.log('Valeurs manquantes mises à jour:', data_stats.missing_values);
        }
        if (duplicateCount) {
            duplicateCount.textContent = data_stats.duplicates.toLocaleString();
            console.log('Doublons mis à jour:', data_stats.duplicates);
        }
        
        // Afficher les sections
        if (fileSection) {
            fileSection.style.display = 'block';
            console.log('Section fichier affichée');
        }
        
        if (fileActionsSection) {
            fileActionsSection.style.display = 'block';
            console.log('Section actions affichée');
        }
        
        // Réattacher les event listeners pour être sûr qu'ils fonctionnent
        attachEventListeners();
        
        // Ajouter plus d'infos dans le tooltip
        const tooltipContent = document.getElementById('tooltipContent');
        if (tooltipContent) {
            tooltipContent.innerHTML = `
                <h4>Détails du fichier</h4>
                <div class="file-stats">
                    <div class="stat-item">
                        <span class="stat-label">Lignes :</span>
                        <span class="stat-value">${data_stats.rows.toLocaleString()}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Colonnes :</span>
                        <span class="stat-value">${data_stats.columns.toLocaleString()}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Valeurs manquantes :</span>
                        <span class="stat-value">${data_stats.missing_values.toLocaleString()}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Doublons :</span>
                        <span class="stat-value">${data_stats.duplicates.toLocaleString()}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Complétude :</span>
                        <span class="stat-value">${data_stats.completeness}%</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Mémoire :</span>
                        <span class="stat-value">${data_stats.memory_mb} MB</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Encodage :</span>
                        <span class="stat-value">${file_info.encoding}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Modifié :</span>
                        <span class="stat-value">${file_info.modified}</span>
                    </div>
                </div>
                <div class="column-types">
                    <h5>Types de colonnes :</h5>
                    ${Object.entries(column_info).map(([col, info]) => 
                        `<small>${col}: ${info.type}</small>`
                    ).join('<br>')}
                </div>
            `;
        }
        
        // Afficher la section fichier
        fileSection.style.display = 'block';
        
        // Log des données pour debug
        console.log('Analyse complète:', data);
    }

    async function handleClean() {
        console.log('🧹 handleClean appelée');
        if (!currentFileData || !analysisComplete) {
            showError('Veuillez d\'abord charger un fichier');
            return;
        }
        
        showLoader('Nettoyage des données en cours...');
        
        try {
            const response = await fetch('/clean-data', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    operations: ['drop_duplicates', 'fill_missing', 'remove_empty_rows']
                })
            });
            
            const result = await response.json();
            
            if (!result.success) {
                throw new Error(result.error);
            }
            
            hideLoader();
            
            // Afficher les résultats du nettoyage
            showCleaningResults(result);
            
        } catch (error) {
            hideLoader();
            showError(`Erreur lors du nettoyage: ${error.message}`);
        }
    }

    function showCleaningResults(result) {
        const { operations_performed, processing_time, final_analysis, summary } = result;
        
        // Créer une modale de résultats
        const modal = document.createElement('div');
        modal.className = 'result-modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Nettoyage terminé</h3>
                    <button class="modal-close">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="cleaning-summary">
                        <p><strong>Opérations effectuées :</strong> ${operations_performed}</p>
                        <p><strong>Temps de traitement :</strong> ${processing_time.toFixed(2)}s</p>
                        <p><strong>Nouvelles dimensions :</strong> ${final_analysis.shape[0]} lignes × ${final_analysis.shape[1]} colonnes</p>
                        <p><strong>Nouvelles valeurs manquantes :</strong> ${final_analysis.missing_total}</p>
                        <p><strong>Nouveaux doublons :</strong> ${final_analysis.duplicates}</p>
                        <p><strong>Nouvelle complétude :</strong> ${final_analysis.completeness}%</p>
                    </div>
                    <div class="action-buttons">
                        <a href="${result.download_url}" class="btn btn-primary" download>
                            Télécharger le fichier nettoyé
                        </a>
                        <button class="btn btn-secondary" onclick="generateReport()">
                            Générer un rapport PDF
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // Fermer la modale
        modal.querySelector('.modal-close').onclick = () => {
            document.body.removeChild(modal);
        };
        
        showSuccess('Données nettoyées avec succès !');
    }

    async function generateReport() {
        showLoader('Génération du rapport en cours...');
        
        try {
            const response = await fetch('/generate-report', {
                method: 'POST'
            });
            
            const result = await response.json();
            
            if (!result.success) {
                throw new Error(result.error);
            }
            
            hideLoader();
            
            if (result.download_url) {
                // Télécharger automatiquement le PDF
                window.open(result.download_url, '_blank');
                showSuccess('Rapport PDF généré avec succès !');
            } else {
                // Afficher le rapport texte
                showTextReport(result.report);
            }
            
        } catch (error) {
            hideLoader();
            showError(`Erreur lors de la génération du rapport: ${error.message}`);
        }
    }

    function handleConvert() {
        if (!currentFileData || !analysisComplete) {
            showError('Veuillez d\'abord charger un fichier');
            return;
        }
        
        // Ouvrir la modale de sélection de format
        const formatModal = document.getElementById('formatModal');
        if (formatModal) {
            formatModal.style.display = 'flex';
        }
    }

    // Utilitaires
    function getFileIcon(extension) {
        const icons = {
            '.csv': 'fas fa-file-csv',
            '.xlsx': 'fas fa-file-excel',
            '.xls': 'fas fa-file-excel',
            '.json': 'fas fa-file-code',
            '.txt': 'fas fa-file-alt'
        };
        return icons[extension] || 'fas fa-file';
    }

    function formatFileSize(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    function showLoader(message) {
        // Créer un loader si nécessaire
        let loader = document.getElementById('loader');
        if (!loader) {
            loader = document.createElement('div');
            loader.id = 'loader';
            loader.className = 'loader-overlay';
            loader.innerHTML = `
                <div class="loader-content">
                    <div class="spinner"></div>
                    <p class="loader-message">${message}</p>
                </div>
            `;
            document.body.appendChild(loader);
        } else {
            loader.querySelector('.loader-message').textContent = message;
            loader.style.display = 'flex';
        }
    }

    function hideLoader() {
        const loader = document.getElementById('loader');
        if (loader) {
            loader.style.display = 'none';
        }
    }

    function showError(message) {
        // Système de notification
        showNotification(message, 'error');
    }

    function showSuccess(message) {
        showNotification(message, 'success');
    }

    function showNotification(message, type) {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.opacity = '0';
            setTimeout(() => {
                if (document.body.contains(notification)) {
                    document.body.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }

    // ===== NOUVELLES FONCTIONS INTERFACE MINIMALISTE =====
    
    function showChartsModal() {
        console.log('📊 showChartsModal appelée');
        if (!analysisComplete) {
            showError('Veuillez d\'abord analyser un fichier');
            return;
        }
        
        if (chartsModal) {
            chartsModal.style.display = 'block';
        }
    }
    
    function hideChartsModal() {
        if (chartsModal) {
            chartsModal.style.display = 'none';
        }
    }
    
    function selectChart(type) {
        console.log('Graphique sélectionné:', type);
        hideChartsModal();
        
        // Ici on pourrait rediriger vers le dashboard ou ouvrir une interface de configuration
        showSuccess(`Graphique "${type}" sélectionné`);
        
        // Exemple: redirection vers dashboard avec paramètre
        // window.location.href = `/dashboard?chart=${type}&file=${currentFileData?.file_info?.name}`;
    }
    
    function goToDashboard() {
        console.log('🏗️ goToDashboard appelée');
        if (!analysisComplete) {
            showError('Veuillez d\'abord analyser un fichier');
            return;
        }
        
        // Redirection vers le dashboard
        window.location.href = '/dashboard';
    }
    
    async function handleConvert() {
        console.log('🔄 handleConvert appelée');
        if (!currentFileData || !analysisComplete) {
            showError('Veuillez d\'abord charger et analyser un fichier');
            return;
        }
        
        // Demander le format de sortie
        const format = prompt('Format de conversion (csv, xlsx, json):', 'csv');
        if (!format) return;
        
        showLoader('Conversion en cours...');
        
        try {
            const response = await fetch('/convert', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    filename: currentFileData.file_info.name,
                    format: format.toLowerCase()
                })
            });
            
            if (!response.ok) {
                throw new Error('Erreur lors de la conversion');
            }
            
            // Télécharger le fichier converti
            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.style.display = 'none';
            a.href = url;
            a.download = currentFileData.file_info.name.replace(/\.[^/.]+$/, `.${format}`);
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
            
            hideLoader();
            showSuccess('Fichier converti et téléchargé !');
            
        } catch (error) {
            hideLoader();
            showError(`Erreur lors de la conversion: ${error.message}`);
        }
    }

    // Fonction pour générer un rapport PDF
    async function generateReport() {
        console.log('📄 generateReport appelée');
        if (!currentFileData || !analysisComplete) {
            showError('Veuillez d\'abord charger et analyser un fichier');
            return;
        }
        
        showLoader('Génération du rapport PDF...');
        
        try {
            const response = await fetch('/generate-report', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                }
            });
            
            if (!response.ok) {
                throw new Error('Erreur lors de la génération du rapport');
            }
            
            // Télécharger le rapport PDF
            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.style.display = 'none';
            a.href = url;
            a.download = `rapport_${currentFileData.file_info.name.replace(/\.[^/.]+$/, '')}.pdf`;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
            
            hideLoader();
            showSuccess('Rapport PDF généré et téléchargé !');
            
        } catch (error) {
            hideLoader();
            showError(`Erreur lors de la génération du rapport: ${error.message}`);
        }
    }

    // ===== FONCTIONS UTILITAIRES =====
    function showLoader(message = 'Chargement...') {
        // Créer le loader s'il n'existe pas
        let loader = document.getElementById('loader');
        if (!loader) {
            loader = document.createElement('div');
            loader.id = 'loader';
            loader.className = 'loader-overlay';
            loader.innerHTML = `
                <div class="loader-content">
                    <div class="spinner"></div>
                    <p class="loader-message">${message}</p>
                </div>
            `;
            document.body.appendChild(loader);
        } else {
            loader.querySelector('.loader-message').textContent = message;
        }
        loader.style.display = 'flex';
    }
    
    function hideLoader() {
        const loader = document.getElementById('loader');
        if (loader) {
            loader.style.display = 'none';
        }
    }
    
    function showSuccess(message) {
        showNotification(message, 'success');
    }
    
    function showError(message) {
        showNotification(message, 'error');
    }
    
    function showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.opacity = '0';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }

    // Fonction pour la transcription audio
    async function handleTranscribe() {
        console.log('🎤 handleTranscribe appelée');
        if (!currentFileData || !analysisComplete) {
            showError('Veuillez d\'abord charger et analyser un fichier');
            return;
        }
        
        // Vérifier d'abord si c'est un fichier audio/vidéo
        showLoader('Vérification du type de fichier...');
        
        try {
            const checkResponse = await fetch('/transcribe/check', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    filename: currentFileData.file_info.name
                })
            });
            
            const checkResult = await checkResponse.json();
            
            if (!checkResult.is_media) {
                hideLoader();
                showError('Ce fichier n\'est pas un média audio/vidéo supporté');
                return;
            }
            
            // Demander le type de tâche
            const task = confirm('Souhaitez-vous traduire en français ?\nOK = Traduire\nAnnuler = Transcrire seulement') 
                ? 'translate' : 'transcribe';
            
            showLoader('Transcription en cours... Cela peut prendre plusieurs minutes.');
            
            const transcribeResponse = await fetch('/transcribe', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    filename: currentFileData.file_info.name,
                    task: task
                })
            });
            
            const transcribeResult = await transcribeResponse.json();
            
            if (!transcribeResponse.ok) {
                throw new Error(transcribeResult.error || 'Erreur lors de la transcription');
            }
            
            // Télécharger le fichier transcrit
            if (transcribeResult.transcription_file) {
                const downloadUrl = `/export/${transcribeResult.transcription_file}`;
                const a = document.createElement('a');
                a.style.display = 'none';
                a.href = downloadUrl;
                a.download = transcribeResult.transcription_file;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
            }
            
            hideLoader();
            showSuccess(`Transcription terminée ! Fichier: ${transcribeResult.transcription_file}`);
            
        } catch (error) {
            hideLoader();
            showError(`Erreur lors de la transcription: ${error.message}`);
        }
    }

    // Rendre les fonctions globales pour les modales
    window.generateReport = generateReport;
    window.handleClean = handleClean;
    window.handleConvert = handleConvert;
    window.handleTranscribe = handleTranscribe;
});